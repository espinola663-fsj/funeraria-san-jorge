// Archivo JavaScript básico para futuras funciones
console.log("Funeraria San Jorge – JavaScript cargado correctamente");
